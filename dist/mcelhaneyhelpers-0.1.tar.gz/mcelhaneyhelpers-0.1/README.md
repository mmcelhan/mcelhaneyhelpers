# mcelhaneyhelpers
Collection of helper and logging functions
