# mcelhaneyhelpers
Collection of helper and logging functions

python setup.py sdist bdist_wheel

local install:

pip install git+https://github.com/mmcelhan/mcelhaneyhelpers.git#egg=mcelhaneyhelpers
